#include <stdio.h>

main ()
{
   printf ("Content-type: text/html\n");
   printf ("\n");
   printf ("<html>\n");
   printf ("<head>\n");
   printf ("<title>Hello World</title>\n");
   printf ("</head>\n");
   printf ("\n");
   printf ("<body>\n");
   printf ("<h1>Hello World</h1>\n");
   printf ("</body>\n");
   printf ("</html>\n");
}
