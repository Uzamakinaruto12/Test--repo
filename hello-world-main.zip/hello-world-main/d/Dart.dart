main() {
  print('Hello World');
}
