import 'package:flutter/widgets.dart';

void main() {
  runApp(
    Text(
      'Hello World',
      textDirection: TextDirection.ltr,
    ),
  );
}
