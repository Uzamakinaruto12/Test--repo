import "stdhpp\stdapi.hcc";

using printf = Console::WriteLn;

namespace
{
    class Application
    {
        public static void main()
        {
            printf("Hello World");
            return;
        }
    };
};