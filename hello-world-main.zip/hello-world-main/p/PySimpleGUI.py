import PySimpleGUI

PySimpleGUI.popup_no_buttons("Hello World")
