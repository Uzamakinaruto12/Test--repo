print "Hello World"
