puts(1, "Hello World")
